
// FETCH FEATURED PROPERTY

$(document).ready(function () {
	$.getJSON("http://192.168.1.211:3000/ui/dashboard/featuredproperty", function (results) {

		var featureitem = '';

		var NOofFeature = results.length;
		console.log(NOofFeature);

		var amenities_value = {
			"AirConditioning": "<i class=\"fa fa-wifi\" aria-hidden=\"true\"></i> Air",
			"AirportTransfer": "<i class=\"fa fa-wifi\" aria-hidden=\"true\"></i> Airport Transfer",
			"Balcony": "<i class=\"fa fa-wifi\" aria-hidden=\"true\"></i> Balcony",
			"Bathtub": "<i class=\"fa fa-wifi\" aria-hidden=\"true\"></i> Bathtub",
			"BusinessFriendly": "<i class=\"fa fa-wifi\" aria-hidden=\"true\"></i> Business Friendly",
			"CarPark": "<i class=\"fa fa-wifi\" aria-hidden=\"true\"></i> Car Park"
		}
		for (i = 0; i <= NOofFeature - 1; i++) {

			featureitem += '<div class="item">' +
			'<div class="imgTitle">' +
			'<a><img src="' + results[i].images.map(image => 'http://192.168.1.211:3000/facility' + image.url) + '"  height="150px" alt="" /></a>' +
			'</div>' +
			'<p style="font-weight:500;font-size:16px;">' + results[i].name + '</p>' +
			'<p style="font-size:12px;">' + amenities_value[results[i].amenities] + '</p>' +

			'</div>';

		};
		$(".Featureprop").html(featureitem);

	});
});
